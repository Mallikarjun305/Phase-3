export class User {
    firstName: string;
    lastName: string;
    userName:string;
    password: string;
    dob:Date;
    phone: number;
    address:string;
    type:string;
    identity:string;
    email: string;
    }

export class Login {
    username:string;
    password: string;
    
}

